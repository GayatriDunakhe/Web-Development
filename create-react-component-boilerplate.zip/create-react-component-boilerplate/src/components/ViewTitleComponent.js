import React from 'react';

function ViewTitleComponent(){

    return (
        <h4>I am a View Title Component!!!</h4>
    );
}

export default ViewTitleComponent;