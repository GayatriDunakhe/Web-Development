import React from 'react';

function BodyRightComponent(){

    return (
        <h4>I am a Body Right Component!!!</h4>
    );
}

export default BodyRightComponent;