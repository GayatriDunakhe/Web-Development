import React from 'react';

function LogoComponent(){

    return (
        <h4>I am a Logo Component!!!</h4>
    );
}

export default LogoComponent;