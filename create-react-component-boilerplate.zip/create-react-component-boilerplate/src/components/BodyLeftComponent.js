import React from 'react';

function BodyLeftComponent(){

    return (
        <h4>I am a Body Left Component!!!</h4>
    );
}

export default BodyLeftComponent;