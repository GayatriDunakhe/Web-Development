import React  from "react";

function FooterComponent(){

    return (
        <div>
            <h1>I am a Footer Component!!</h1>
        </div>
    );
}

export default FooterComponent;