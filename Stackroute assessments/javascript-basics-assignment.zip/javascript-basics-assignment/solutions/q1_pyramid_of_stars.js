/* Write a program to build a `Pyramid of stars` of given height */

const buildPyramid = () => {
	// Write your code here
};

/* For example,
INPUT - buildPyramid(6)
OUTPUT -
     *
    * *
   * * *
  * * * *
 * * * * *
* * * * * *

*/

module.exports = buildPyramid;
