// Write a program to display one result card of 10 students
// with their name and percentage
// Out of 10 students, 5 has subjects - Grammer and Accounts
// and other 5 has subjects -  Grammer and Physics

// Hint : You need to calculate percentage of 10 students having different set of subjects.
//        You can assume their scores on their respective subjects.


// Write your code here
