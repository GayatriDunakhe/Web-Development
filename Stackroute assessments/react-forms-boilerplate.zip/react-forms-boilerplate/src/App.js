import logo from './logo.svg';
import './App.css';
import Calculator from './calculator/calculator'

function App() {
  return (
    <div className="App">
      <Calculator/>
    </div>
  );
}

export default App;
