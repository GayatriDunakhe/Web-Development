import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

function BookListComponent() {

  const [bookname, setBookName] = useState('');
  const [author, setAuthor] = useState('');
  const [publication, setPublication] = useState('');
  const [price, setPrice] = useState('');

  const [books, setBooks] = useState([]);
  const [errorMessage, setErrorMessage] = useState('');

  const handleAddBook = () => {
    if (!bookname || !author || !publication || !price) {
      setErrorMessage('All fields are required.');
      return;
    }

    const newBook = { bookname, author, publication, price };
    setBooks([...books, newBook]);

    setBookName('');
    setAuthor('');
    setPublication('');
    setPrice('');
    setErrorMessage('');
  };

  return (
    <div className="container p-4 m-4 border border-dark">

      <div className="row text-left">

        <div className="col-md-6">
            Name of the book:
            <input type="text" value={bookname} onChange={(e) => setBookName(e.target.value)}/>
        </div>

        <div className="col-md-6">
            Author:
            <input type="text" value={author} onChange={(e) => setAuthor(e.target.value)}/>
        </div>
      </div>

      <br/>

      <div className="row">

        <div className="col-md-6">
            Publication:
            <input type="text" value={publication} onChange={(e) => setPublication(e.target.value)}/>
        </div>

        <div className="col-md-6">
            Price:
            <input type="number" value={price} onChange={(e) => setPrice(e.target.value)}/>
        </div>
      </div>

      <br/>

      <div className="row">

        <div className="col-md-6">

          {errorMessage && <p className="text-danger">{errorMessage}</p>}

          <button className="btn btn-outline-secondary" onClick={handleAddBook}>
            Add A Book
          </button>

        </div>

      </div>

      <div className="row mt-4">

        <div className="col-md-12">

          <table className="table table-bordered">

            <tr>
                <th>NAME</th>
                <th>AUTHOR</th>
                <th>PUBLICATION</th>
                <th>PRICE</th>
            </tr>
            
            {books.map((book, index) => (
            <tr key={index}>
                <td>{book.bookname}</td>
                <td>{book.author}</td>
                <td>{book.publication}</td>
                <td>{book.price}</td>
            </tr>
            ))}

          </table>
        </div>
      </div>
    </div>
  );
}

export default BookListComponent;
