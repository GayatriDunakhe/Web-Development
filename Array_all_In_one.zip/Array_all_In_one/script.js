        let myArray = [];
 
        function displayList() {
            
            const myList = document.getElementById('myList');
            myList.innerHTML = ''; 
             myArray.forEach(item => {
                const li = document.createElement('li'); 
                li.textContent = item; 
                myList.appendChild(li); 
            });
        }

       
        function addName() {
            const name = prompt('Enter a name to add:');       
            if (name) {  
                myArray.push(name);
                displayList();
            }
        }

        
        function deleteName() {
            
            const nameToDelete = prompt('Enter a name to delete:');
            const index = myArray.indexOf(nameToDelete);

            if (index !== -1) {
                myArray.splice(index, 1);
                displayList();
            }
        }

       
        function searchName() {
           
            const nameToSearch = prompt('Enter a name to search:');
            const index = myArray.indexOf(nameToSearch);

            if (index !== -1) {
               
                alert(`${nameToSearch} found at index ${index}`);
            } else {
               
                alert(`${nameToSearch} not found`);
            }
        }

       
        function updateName() {  
            const nameToUpdate = prompt('Enter a name to update:');
            const newName = prompt('Enter the new name:');
            const index = myArray.indexOf(nameToUpdate);
         
            if (index !== -1) {
                myArray[index] = newName;
                displayList();
            }
        }

        displayList();
    
   